const initData = require('./initData');

module.exports = {
  initData,
};
