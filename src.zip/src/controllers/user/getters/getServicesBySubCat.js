const { isValidObjectId } = require("mongoose");
const { ApiError } = require("../../../errorHandler");
const { Service } = require("../../../models");
const Cart = require("../../../models/cart");
const { verifyAccessToken } = require("../../../utils");

// const getServicesBySubCat = async (req, res, next) => {
//   try {
//     const sub_category_id = req.body.id;
//     let userId = req.body.userId; // Get the userId from the request body

//     if (sub_category_id.length <= 0) {
//       throw new ApiError("subcategory Id is required.", 400);
//     }

//     sub_category_id.forEach((id) => {
//       if (!isValidObjectId(id.trim())) {
//         throw new ApiError(`Invalid Category ID: ${id}`, 400);
//       }
//     });

//     const subcat = await Service.find({
//       sub_category: { $in: sub_category_id },
//       status: true,
//     });

//     let cartProducts = [];
//     if (userId) {
//       const decoded = verifyAccessToken(userId);
//       userId = decoded.id;
//       const cart = await Cart.findOne({ userId });
     
//       if (cart) {
//         cartProducts = cart.products.map((product) => ({
//           productId: product.productId.toString(),
//           quantity: product.quantity,
//         }));
//       }
//     }

//     const subcatWithCartInfo = subcat.map((sub) => {
//       const productInCart = cartProducts.find(
//         (p) => p.productId === sub._id.toString()
//       );
//       return {
//         ...sub.toObject(),
//         inCart: !!productInCart,
//         quantity: productInCart ? productInCart.quantity : 0,
//       };
//     });

//     return res.status(200).json({
//       status: true,
//       size: subcatWithCartInfo.length,
//       message: "Services Listing",
//       data: subcatWithCartInfo,
//     });
//   } catch (error) {
//     next(error);
//   }
// };

const getServicesBySubCat = async (req, res, next) => {
  try {
    const { id: sub_category_id = [], userId, serviceId } = req.body;

    let subCategoryIds = [...sub_category_id];

    if (serviceId) {
      const service = await Service.findById(serviceId);
      if (!service) {
        throw new ApiError(`Service not found for ID: ${serviceId}`, 404);
      }
      const serviceSubCategoryId = service.sub_category.toString();
  
      if (!subCategoryIds.includes(serviceSubCategoryId)) {
        subCategoryIds.push(serviceSubCategoryId);
      }
    }

    if (subCategoryIds.length <= 0) {
      throw new ApiError("Subcategory ID is required.", 400);
    }

    subCategoryIds.forEach((id) => {
      if (!isValidObjectId(id.trim())) {
        throw new ApiError(`Invalid Subcategory ID: ${id}`, 400);
      }
    });

    const subcat = await Service.find({
      sub_category: { $in: subCategoryIds },
      status: true,
    }).populate("reviews")

    let cartProducts = [];
    if (userId) {
      const decoded = verifyAccessToken(userId);
      const userIdDecoded = decoded.id;
      const cart = await Cart.findOne({ userId: userIdDecoded });

      if (cart) {
        cartProducts = cart.products.map((product) => ({
          productId: product.productId.toString(),
          quantity: product.quantity,
        }));
      }
    }

    let subcatWithCartInfo = subcat.map((sub) => {
      const productInCart = cartProducts.find(
        (p) => p.productId === sub._id.toString()
      );
      return {
        ...sub.toObject(),
        inCart: !!productInCart,
        quantity: productInCart ? productInCart.quantity : 0,
      };
    });

    // Sort the services to have the one with the provided serviceId at the top
    if (serviceId) {
      subcatWithCartInfo = subcatWithCartInfo.sort((a, b) => {
        if (a._id.toString() === serviceId) return -1;
        if (b._id.toString() === serviceId) return 1;
        return 0;
      });
    }

    return res.status(200).json({
      status: true,
      size: subcatWithCartInfo.length,
      message: "Services Listing",
      data: subcatWithCartInfo,
    });
  } catch (error) {
    next(error);
  }
}


module.exports = getServicesBySubCat;

// const getServicesBySubCat = async (req, res, next) => {
//   try {
//     const sub_category_id = req.body.id || [];
//     let userId = req.body.userId; // Get the userId from the request body

//     // Validate category IDs if provided
//     if (sub_category_id.length > 0) {
//       sub_category_id.forEach((id) => {
//         if (!isValidObjectId(id.trim())) {
//           throw new ApiError(`Invalid Category ID: ${id}`, 400);
//         }
//       });
//     }

//     let subcat = [];
//     if (sub_category_id.length > 0) {
//       subcat = await Service.find({ sub_category: { $in: sub_category_id } });
//     }

//     if (subCategoryIds.length > 0) {
//       // Get the parent categories of the provided subcategory IDs
//       const parentCategories = await SubCategory.find({
//         _id: { $in: subCategoryIds },
//       }).distinct("category");
//       const additionalSubcats = await SubCategory.find({
//         category: { $in: parentCategories },
//       });

//       // Combine the results, avoiding duplicates
//       const combinedSubcats = [...subcat, ...additionalSubcats].reduce(
//         (acc, curr) => {
//           if (!acc.find((sub) => sub._id.toString() === curr._id.toString())) {
//             acc.push(curr);
//           }
//           return acc;
//         },
//         []
//       );
//       subcat = combinedSubcats;
//     }

//     let cartProducts = [];
//     if (userId) {
//       const decoded = verifyAccessToken(userId);
//       userId = decoded.id;
//       const cart = await Cart.findOne({ userId });
//       if (cart) {
//         cartProducts = cart.products.map((product) => ({
//           productId: product.productId.toString(),
//           quantity: product.quantity,
//         }));
//       }
//     }

//     const subcatWithCartInfo = subcat.map((sub) => {
//       const productInCart = cartProducts.find(
//         (p) => p.productId === sub._id.toString()
//       );
//       return {
//         ...sub.toObject(),
//         inCart: !!productInCart,
//         quantity: productInCart ? productInCart.quantity : 0,
//       };
//     });

//     return res.status(200).json({
//       status: true,
//       size: subcatWithCartInfo.length,
//       message: "Sub Category Listing",
//       data: subcatWithCartInfo,
//     });
//   } catch (error) {
//     next(error);
//   }
// };