const { ApiError } = require('../../../errorHandler');
const { getOtp, sendOtpToPhone } = require('../../../utils');
const { Admin } = require('../../../models');

const getAdminOtp = async (req, res, next) => {
  try {
    const { email } = req.body;

    if (!email) throw new ApiError('Email is required.', 400);
    const admin = await Admin.findOne({ email });
    if (!admin) throw new ApiError('Invalid credentials.', 400);

    admin.otp = getOtp();
    admin.otp_expiry = new Date(Date.now() + 2 * 60 * 1000);
    await admin.save();
    //send otp to phone
    await sendOtpToPhone(admin.phone, admin.otp);
    //send otp to phone
    return res.status(200).json({
      status: true,
      message: 'OTP send to registered number.',
    });
  } catch (error) {
    next(error);
  }
};

module.exports = getAdminOtp;
