const getServiceFaq= async(req,res)=>{}

module.exports=getServiceFaq